document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.btn').addEventListener('click', verify);
});

function verify() {
    var email = document.querySelector('.form-style[name="email"]').value;
    var password = document.querySelector('.form-style[name="senha"]').value;

    console.log(email);
  
    if (email === '' || password === '') {
        alert('Por favor, preencha tanto o campo de e-mail quanto o de senha.');
        document.querySelector('.btn').removeEventListener('click', verify);
        return false;
    } else {
        window.location.href = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8_1foda5J6xSTq3aCj3mzpSENKhelll00Lnqsf4_Z7w&s';
    }
    function comparePasswords() {
    var senha = document.getElementById('senha').value;
    var confirmarSenha = document.getElementById('confirmarSenha').value;
    var senhaError = document.getElementById('senhaError');

    if (senha === confirmarSenha) {
        senhaError.style.display = 'none'; // Remove a mensagem de erro se as senhas coincidirem
    } else {
        senhaError.style.display = 'block'; // Exibe a mensagem de erro se as senhas não coincidirem
    }
}

  
    // Continue with the login process
}
